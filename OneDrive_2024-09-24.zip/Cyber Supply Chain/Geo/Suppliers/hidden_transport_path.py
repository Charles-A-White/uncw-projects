import simplekml

#### IMPORTANT: From original supplier paths, remove 17, 28 and 47

# Define the fixed first coordinate
fixed_coordinate = (-121.96704992851325, 37.371043168522476)

# Define the second coordinates for each line path
second_coordinates = [
    (-72.9433333,41.6705556),
    (-122.0136111,37.4155556),
    (-111.8855556,33.2844444),
]

kml = simplekml.Kml()

for i, second_coord in enumerate(second_coordinates):
    
    coordinates = [fixed_coordinate, second_coord]
    
    ls = kml.newlinestring(name=f"LinePath_{i+1}")
    ls.coords = coordinates
    ls.tessellate = 1
    ls.altitudemode = simplekml.AltitudeMode.clamptoground
    ls.style.linestyle.width = 3
    ls.style.linestyle.color = simplekml.Color.red

kml.save("hidden_transport_path.kml")
