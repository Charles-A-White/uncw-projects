import simplekml

def create_kml_file(coordinates, output_file):
    kml = simplekml.Kml()

    for i, coord in enumerate(coordinates):
        lon, lat = coord
        kml.newpoint(name=f"Placemark {i+1}", coords=[(lon, lat)])

    kml.save(output_file)
    print(f"KML file '{output_file}' created successfully!")

if __name__ == "__main__":
    coordinates = [
        (52.2306861, 8.5614289),
        (2.4796278, 54.5541778),
        (37.6263306, 55.7543556),
        (37.6296028, 55.7467722),
        (103.9826028, 34.1806722),
        (116.0309194, 39.9697111),
        (69.3872917, 30.3862556),
        (53.8754472, 32.2624806),
        (56.164525, 54.2312222),
        (127.5319917, 40.341325)
    ]

    output_file = "placemarks.kml"
    create_kml_file(coordinates, output_file)
