import simplekml

#### Make sure to go on cmd prompt and type:
#### py -m pip install simplekml

fixed_coordinate = (-121.96704992851325, 37.371043168522476)


#### IMPORTANT -- We probably don't
#### have the same coordinates on our placemarkers
#### Either change your placemarkers to these or
#### change these coordinates to yours
#### But I recommend you just change yours

second_coordinates = [
    (52.2306861, 8.5614289),
    (2.4796278, 54.5541778),
    (37.6263306, 55.7543556),
    (37.6296028, 55.7467722),
    (103.9826028, 34.1806722),
    (116.0309194, 39.9697111),
    (69.3872917, 30.3862556),
    (53.8754472, 32.2624806),
    (56.164525, 54.2312222),
    (127.5319917, 40.341325)
]

kml = simplekml.Kml()

for i, second_coord in enumerate(second_coordinates):
    
    coordinates = [fixed_coordinate, second_coord]
    
    ls = kml.newlinestring(name=f"Attack_LinePath_{i+1}")
    ls.coords = coordinates
    ls.tessellate = 1
    ls.altitudemode = simplekml.AltitudeMode.clamptoground
    ls.style.linestyle.width = 3
    ls.style.linestyle.color = simplekml.Color.orange

kml.save("Attack_Vector_Path.kml")
